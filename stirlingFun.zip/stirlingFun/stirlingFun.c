#include <math.h>

/*Function computes and returns the factorial of N which is
passed to the function as paramter*/
double factorial(int N)
{
   int i;
   double fact=1;
   if(N!=0)
   {
       for(i=1;i<=N;i++)
           fact = fact * i;
   }

   /*Returns the factorial of N*/
   return fact;
}

/*Function that computes and return x raise to power n */
double myPow(double x, int n)
{
   int i;
   double power=x;
   for(i=2;i<=n;i++)
   {
       power = power * x;
   }

   /*Returns the calculated power*/
   return power;
}

/*Funcion uses the Stirling approximation to compute and return
the factorial of N which is passed to the function as paramter
*/
double stirling(int N)
{
   double approx;

   /*Computing the factorial using Stirling approximation
      by using myPow() function to calculate the raise to power
   */
   approx = sqrt(2*M_PI*N)*myPow((N/M_E),N);

   /*Returns the calculated Stirling approximation value*/
   return approx;
}
