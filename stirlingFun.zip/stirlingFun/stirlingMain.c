#include <stdio.h>
#include "stirlingFun.h"

/*main function that asks the user for N, and then
writes out a table for n from 1 to N where each
line has n, n!, and the Stirling approximation to n!
*/
int main()
{
   int N, n;

   /*Prompt & read value of N from user*/
   printf("Enter N -->");
   scanf("%d",&N);

   /*Print heading*/
   printf("   n\t\tn!\t\tapprox.\n");
   printf("--------*--------------------*--------------------\n");
   /*Print table for n from 1 to N where each line has n, n! by
      calling factorial(), stirling() functions
   */
   for(n=0;n<=N;n++)
       printf("%4d\t%15.0lf\t%25.4lf\n",n, factorial(n), stirling(n));

   return 0;
}
