#include "stirlingFun.c"

/*Prototypes for three functions*/
double factorial(int N);
double myPow(double x, int n);
double stirling(int N);
